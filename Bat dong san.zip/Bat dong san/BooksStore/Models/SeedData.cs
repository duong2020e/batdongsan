﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

using Microsoft.EntityFrameworkCore;

namespace BooksStore.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            BooksStoreDbContext context =
            app.ApplicationServices.CreateScope().ServiceProvider.GetRequiredService < BooksStoreDbContext > ();
            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }
            if (!context.Books.Any())
            {
                context.Books.AddRange(
                new Book
                {
                    hinhanh = " https://luatminhgia.com.vn/LMG/articles/4/21459/mua-dat-chua-lam-thu-tuc-sang-ten-thi-ben-mua-chet-xu-ly-the-nao--21459.jpg",
                    Title = "Bất động sản Diên Toàn  ",
                    Description = "Diện Tích : 130m ",
                    Genre = "Còn Bán ",
                    Price = 11.98m
                },
                new Book
                {
                    hinhanh = " https://luatminhgia.com.vn/LMG/articles/4/21459/mua-dat-chua-lam-thu-tuc-sang-ten-thi-ben-mua-chet-xu-ly-the-nao--21459.jpg",
                    Title = "Bất động sản Diên Điền ",
                    Description = "Diện Tích : 200m ",
                    Genre = "Đất Dính dự án ",
                    Price = 17.46m
                },
                new Book
                {
                    hinhanh = " https://luatminhgia.com.vn/LMG/articles/4/21459/mua-dat-chua-lam-thu-tuc-sang-ten-thi-ben-mua-chet-xu-ly-the-nao--21459.jpg",
                    Title = "Bất động sản Diên Sơn ",
                    Description = "Diện Tích : 220m ",
                    Genre = "Đất Trông cây lâu năm  ",
                    Price = 13.41m
                },

                new Book
                {
                    hinhanh = " https://luatminhgia.com.vn/LMG/articles/4/21459/mua-dat-chua-lam-thu-tuc-sang-ten-thi-ben-mua-chet-xu-ly-the-nao--21459.jpg",
                    Title = "Bất động sản Diên Thọ ",
                    Description = "Diện Tích : 290m",
                    Genre = "Đất nhà ở ",
                    Price = 18.69m
                },
                new Book
                {
                    hinhanh = "https://luatminhgia.com.vn/LMG/articles/4/21459/mua-dat-chua-lam-thu-tuc-sang-ten-thi-ben-mua-chet-xu-ly-the-nao--21459.jpg",
                    Title = "Bất động sản Nha Trang ",
                    Description = "Diện Tích : 110m",
                    Genre = "Dất đô thị ",
                    Price = 31.26m
                }
                );

                context.SaveChanges();
            }
        }
    }
}